--
-- PostgreSQL database dump
--

\restrict mK69sgcrazJzU1URzwcCYYEwoaj6fxJePvsvpWYSKgADsKkz8lPaGWkAI83G2u6

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS '';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: test_resilience; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.test_resilience (
    id integer NOT NULL,
    note text
);


ALTER TABLE public.test_resilience OWNER TO postgres;

--
-- Name: test_resilience_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.test_resilience_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.test_resilience_id_seq OWNER TO postgres;

--
-- Name: test_resilience_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.test_resilience_id_seq OWNED BY public.test_resilience.id;


--
-- Name: test_resilience id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_resilience ALTER COLUMN id SET DEFAULT nextval('public.test_resilience_id_seq'::regclass);


--
-- Data for Name: test_resilience; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.test_resilience (id, note) FROM stdin;
1	avant
2	sauvegarde
\.


--
-- Name: test_resilience_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.test_resilience_id_seq', 2, true);


--
-- Name: test_resilience test_resilience_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_resilience
    ADD CONSTRAINT test_resilience_pkey PRIMARY KEY (id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict mK69sgcrazJzU1URzwcCYYEwoaj6fxJePvsvpWYSKgADsKkz8lPaGWkAI83G2u6

